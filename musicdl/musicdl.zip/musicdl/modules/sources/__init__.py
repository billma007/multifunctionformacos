'''initialize'''
from .kuwo import Kuwo
from .migu import Migu
from .joox import Joox
from .lizhi import Lizhi
from .kugou import Kugou
from .yiting import YiTing
from .netease import Netease
from .qqmusic import QQMusic
from .qianqian import Qianqian
from .fivesing import FiveSing